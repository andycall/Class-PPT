/**
 * Created by andycall on 14-3-23.
 */

//function $$(id){
//    return document.getElementById(id);
//}

function $$(id){
    return typeof id == 'string' ? document.getElementById(id) : id;
}

function css(ele,attr,value){
    //ele.style[attr];
    //IE : document.currentStyle;
    //others : window.getComputedStyle(ele,null)[attr];
    //arguments.length

    var isSet,isIe,styleValue;

    isSet = arguments.length > 2 ? true : false;
    isIe  = document.currentStyle ? true :false;

    if(!isSet){
        //get
        if(isIe){
            styleValue = document.currentStyle[attr];
        }
        else{
            styleValue = window.getComputedStyle(ele,null)[attr];
        }
        return styleValue;
    }
    else{
        //set
        ele.style[attr] = value;
    }
}
//浏览器的刷新率是60Hz = 16.66666.. ms
//IE8的刷新 ！= 60Hz 。
//jQuery 刷新70Hz 。
//constant($$("moveBox"),{left : 100,top:100},1000);
function constant(ele,json,speed,fn){
    var time = 1000 / 60;
    var S = speed || 1000;
    var oldValue,len;
    var jsonLen = Object.keys(json).length;
    for(var key in json){
        if(json.hasOwnProperty(key)){
            oldValue = parseFloat(css(ele,key));
            len = json[key] - oldValue;
//            debugger;
//            ele[key.toString()+"speed"] = len;
            S = len / (speed/time);
            ele[key.toString() + "speed"] = S;
        }
    }
//    var oldValue = parseFloat(css(ele,attr));
//    var len = value - oldValue;

//    S = len / (S / time); // 每刷新一次要运动的距离

//    debugger;
    if(ele.timer){
        clearInterval(ele.timer);
    }
    var count = 1;

    ele.timer = setInterval(function(){
        for(var key in json){
            oldValue = parseFloat(css(ele,key));
            var newValue = oldValue + ele[key.toString() + "speed"];
            //当动画终止的时候
//            debugger
            if(json[key] - newValue < ele[key.toString() + "speed"]){
                newValue = json[key];
                clearInterval(ele.timer);
                css(ele,key,json[key] + 'px');
//                debugger;
                if(count < jsonLen){
                    if(typeof fn == 'function'){
                        fn();
                        // fn.apply(this);
                    }
                }
                count++;
            }
            css(ele,key,newValue + 'px');
        }
    },time);
}

//Array.prototype.forEach();
//Array.prototype.every();
//Array.prototype.some();
//Array.prototype.reduce();
//Array.prototype.map();

//var test = [1,2,3,4,5,6,7,8];
//test.forEach(function(value,index,arr){
//    value = value + 1;
//    console.log(value);
//});



function each(ele,fn){
    var _arr;
    if(ele.forEach){
        return ele.forEach(fn);
    }
    else{
        for(var i = 0,len = arr.length; i < len; i ++){
            fn.call(ele,ele[i],i,ele);
        }
    }
}
//<div class="nav nav1 nav2 nav3"></div>
function getElementsByClassNameFackEdition(name){
//    var tags = [];
    var _arr = [];
//    if(document.getElementsByClassName){
//        return document.getElementsByClassName(name);
//    }
//    else{
    var  tags = document.getElementsByTagName("*");
//    debugger;
        for(var i = 0,len = tags.length; i < len ; i ++){

            var tmps = tags[i].className.split(" ");

            for(var j = 0,lens = tmps.length; j < lens; j ++){
                if(tmps[j] == name){

                    _arr.push(tags[i]);
                }
            }
//        }
        }
    return _arr;
//    }

}


//constant($$("moveBox"),{left:100,top:100},1000,function(){alert(1)});
//getElementsByClassNameFackEdition("nav")



